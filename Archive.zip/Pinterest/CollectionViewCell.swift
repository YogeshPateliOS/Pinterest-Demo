//
//  CollectionViewCell.swift
//  Pinterest
//
//  Created by Yogesh Patel on 18/11/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imgView: UIImageView!
}
